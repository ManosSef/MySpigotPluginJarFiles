package whatevertheheck.customenchtest;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.enchantments.EnchantmentTarget;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import me.manossef.api.wrappers.CustomEnchantment;
import me.manossef.api.wrappers.EnchantmentWrapper;

public class Main extends JavaPlugin {
	
	public static final Enchantment CUSTOM_ENCH_TEST = new EnchantmentWrapper("custom_ench_test", "Custom Ench Test", 1, 1, EnchantmentTarget.BREAKABLE, true, false);
	
	@Override
	public void onEnable() {
		
		CustomEnchantment.register(CUSTOM_ENCH_TEST);
		
	}
	
	@Override
	public void onDisable() {
		
	}
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if (cmd.getName().equalsIgnoreCase("givemetool")) {
			
			if (!(sender instanceof Player)) {
				
				sender.sendMessage("The console cannot own items!");
				return true;
				
			}
			Player player = (Player) sender;
			player.getInventory().addItem(this.getTool());
			player.sendMessage(ChatColor.AQUA + "You have been given an item with a weird enchantment.");
			return true;
		}
		return false;
		
	}
	
	public ItemStack getTool() {
		
		ItemStack item = new ItemStack(Material.DIAMOND_SWORD);
		item.addUnsafeEnchantment(Main.CUSTOM_ENCH_TEST, 1);
		ItemMeta meta = item.getItemMeta();
		List<String> lore = new ArrayList<String>();
		lore.add(ChatColor.GRAY + "Custom Ench Test I");
		meta.setLore(lore);
		item.setItemMeta(meta);
		return item;
		
	}
}
